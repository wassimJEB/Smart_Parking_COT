"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_sensor-details_sensor-details_module_ts"],{

/***/ 6252:
/*!***********************************************************************!*\
  !*** ./src/app/pages/sensor-details/sensor-details-routing.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SensorDetailsPageRoutingModule": () => (/* binding */ SensorDetailsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _sensor_details_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./sensor-details.page */ 1820);




const routes = [
    {
        path: '',
        component: _sensor_details_page__WEBPACK_IMPORTED_MODULE_0__.SensorDetailsPage
    }
];
let SensorDetailsPageRoutingModule = class SensorDetailsPageRoutingModule {
};
SensorDetailsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SensorDetailsPageRoutingModule);



/***/ }),

/***/ 5747:
/*!***************************************************************!*\
  !*** ./src/app/pages/sensor-details/sensor-details.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SensorDetailsPageModule": () => (/* binding */ SensorDetailsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8346);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 8099);
/* harmony import */ var _sensor_details_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./sensor-details-routing.module */ 6252);
/* harmony import */ var _sensor_details_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sensor-details.page */ 1820);







let SensorDetailsPageModule = class SensorDetailsPageModule {
};
SensorDetailsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _sensor_details_routing_module__WEBPACK_IMPORTED_MODULE_0__.SensorDetailsPageRoutingModule
        ],
        declarations: [_sensor_details_page__WEBPACK_IMPORTED_MODULE_1__.SensorDetailsPage]
    })
], SensorDetailsPageModule);



/***/ }),

/***/ 1820:
/*!*************************************************************!*\
  !*** ./src/app/pages/sensor-details/sensor-details.page.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SensorDetailsPage": () => (/* binding */ SensorDetailsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _C_Users_21622_Project_COT_Mobile_node_modules_ngtools_webpack_src_loaders_direct_resource_js_sensor_details_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./sensor-details.page.html */ 1679);
/* harmony import */ var _sensor_details_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sensor-details.page.scss */ 1260);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);




let SensorDetailsPage = class SensorDetailsPage {
    constructor() { }
    ngOnInit() {
    }
};
SensorDetailsPage.ctorParameters = () => [];
SensorDetailsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-sensor-details',
        template: _C_Users_21622_Project_COT_Mobile_node_modules_ngtools_webpack_src_loaders_direct_resource_js_sensor_details_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_sensor_details_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], SensorDetailsPage);



/***/ }),

/***/ 1679:
/*!******************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/sensor-details/sensor-details.page.html ***!
  \******************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-title>sensorDetails</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n</ion-content>\n");

/***/ }),

/***/ 1260:
/*!***************************************************************!*\
  !*** ./src/app/pages/sensor-details/sensor-details.page.scss ***!
  \***************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzZW5zb3ItZGV0YWlscy5wYWdlLnNjc3MifQ== */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_sensor-details_sensor-details_module_ts.js.map