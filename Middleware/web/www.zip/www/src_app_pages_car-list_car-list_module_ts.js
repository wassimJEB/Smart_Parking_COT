"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_car-list_car-list_module_ts"],{

/***/ 3908:
/*!***********************************************************!*\
  !*** ./src/app/pages/car-list/car-list-routing.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CarListPageRoutingModule": () => (/* binding */ CarListPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _car_list_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./car-list.page */ 9972);




const routes = [
    {
        path: '',
        component: _car_list_page__WEBPACK_IMPORTED_MODULE_0__.CarListPage
    }
];
let CarListPageRoutingModule = class CarListPageRoutingModule {
};
CarListPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CarListPageRoutingModule);



/***/ }),

/***/ 140:
/*!***************************************************!*\
  !*** ./src/app/pages/car-list/car-list.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CarListPageModule": () => (/* binding */ CarListPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8346);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 8099);
/* harmony import */ var _car_list_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./car-list-routing.module */ 3908);
/* harmony import */ var _car_list_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./car-list.page */ 9972);







let CarListPageModule = class CarListPageModule {
};
CarListPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _car_list_routing_module__WEBPACK_IMPORTED_MODULE_0__.CarListPageRoutingModule
        ],
        declarations: [_car_list_page__WEBPACK_IMPORTED_MODULE_1__.CarListPage]
    })
], CarListPageModule);



/***/ }),

/***/ 9972:
/*!*************************************************!*\
  !*** ./src/app/pages/car-list/car-list.page.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CarListPage": () => (/* binding */ CarListPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _C_Users_21622_Project_COT_Mobile_node_modules_ngtools_webpack_src_loaders_direct_resource_js_car_list_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./car-list.page.html */ 5726);
/* harmony import */ var _car_list_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./car-list.page.scss */ 8668);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _services_list_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/list.service */ 1973);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ 3981);






let CarListPage = class CarListPage {
    constructor(list, httpClient) {
        this.list = list;
        this.httpClient = httpClient;
        this.getData = [];
    }
    ngOnInit() {
        this.Afficher();
    }
    Afficher() {
        const Table = this.list.List().subscribe(data => {
            console.log(data);
            this.getData = data;
        });
    }
};
CarListPage.ctorParameters = () => [
    { type: _services_list_service__WEBPACK_IMPORTED_MODULE_2__.ListService },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient }
];
CarListPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-car-list',
        template: _C_Users_21622_Project_COT_Mobile_node_modules_ngtools_webpack_src_loaders_direct_resource_js_car_list_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_car_list_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], CarListPage);



/***/ }),

/***/ 1973:
/*!******************************************!*\
  !*** ./src/app/services/list.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ListService": () => (/* binding */ ListService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./http.service */ 7754);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 3252);




let ListService = class ListService {
    constructor(httpService, router) {
        this.httpService = httpService;
        this.router = router;
    }
    List() {
        return this.httpService.getMeth('car-list');
    }
};
ListService.ctorParameters = () => [
    { type: _http_service__WEBPACK_IMPORTED_MODULE_0__.HttpService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__.Router }
];
ListService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], ListService);



/***/ }),

/***/ 5726:
/*!******************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/car-list/car-list.page.html ***!
  \******************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-title>CarList</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-button expand=\"block\" share=\"round\" color=\"success\" (click)=\"Afficher()\" >Afficher</ion-button>\n<ion-badge color=\"danger\" slot=\"end\"></ion-badge>\n\n\n\n    <ion-content>\n\n\n      <ion-grid class=\"ion-text-center\">\n\n        <ion-row class=\"ion-margin\">\n          <ion-col>\n            <ion-title>\n              <ion-text color=\"default\">\n                Data From Mqtt\n              </ion-text>\n            </ion-title>\n          </ion-col>\n        </ion-row>\n\n        <ion-row class=\"header-row\">\n          <ion-col>\n            <ion-text>DateTime</ion-text>\n          </ion-col>\n\n          <ion-col>\n            <ion-text>License Plate</ion-text>\n          </ion-col>\n\n          <ion-col>\n            <ion-text>Suspect</ion-text>\n          </ion-col>\n        </ion-row>\n\n\n        <ion-row *ngFor=\"let tab of getData\">\n          <ion-col>\n            <ion-text>\n              {{tab.datetime}}\n            </ion-text>\n          </ion-col>\n\n          <ion-col>\n            <ion-text>\n              {{tab.licensePlate}}\n            </ion-text>\n          </ion-col>\n\n          <ion-col>\n            <ion-text>\n              {{tab.Suspect}}\n            </ion-text>\n          </ion-col>\n        </ion-row>\n\n      </ion-grid>\n    </ion-content>\n\n\n\n");

/***/ }),

/***/ 8668:
/*!***************************************************!*\
  !*** ./src/app/pages/car-list/car-list.page.scss ***!
  \***************************************************/
/***/ ((module) => {

module.exports = ".header-row {\n  background: #7163AA;\n  color: #fff;\n  font-size: 18px;\n}\n\nion-col {\n  border: 1px solid #ECEEEF;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhci1saXN0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLG1CQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7QUFDRjs7QUFFQTtFQUNFLHlCQUFBO0FBQ0YiLCJmaWxlIjoiY2FyLWxpc3QucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmhlYWRlci1yb3cge1xyXG4gIGJhY2tncm91bmQ6ICM3MTYzQUE7XHJcbiAgY29sb3I6ICNmZmY7XHJcbiAgZm9udC1zaXplOiAxOHB4O1xyXG59XHJcblxyXG5pb24tY29sIHtcclxuICBib3JkZXI6IDFweCBzb2xpZCAjRUNFRUVGO1xyXG59XHJcbiJdfQ== */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_car-list_car-list_module_ts.js.map